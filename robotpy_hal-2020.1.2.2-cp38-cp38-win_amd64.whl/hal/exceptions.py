class HALError(RuntimeError):
    pass
